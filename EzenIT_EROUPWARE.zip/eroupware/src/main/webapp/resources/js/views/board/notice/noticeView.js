/*$(function() {
	
	var content = $(".contentHidden").val();
	$(".showContent").append(content);
	
	
});
*/
/*var ckeditor_config = {

	resize_enaleb: false,

	enterMode: CKEDITOR.ENTER_BR,

	shiftEnterMode: CKEDITOR.ENTER_P,

	filebrowserUploadUrl: "이미지 업로드 처리를 하는 controller명"

};*/


