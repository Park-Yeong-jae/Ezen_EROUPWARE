/**
 * 
 */
 
 $(function() {
	
	$("#utiltest").click(function() {
		location.href = utils.getContextPath() + "/main";
	});
});