package com.ezenit.eroupware.example.service;

import com.ezenit.eroupware.example.bean.ExampleDTO;

public interface ExampleService {
	public int insertExample(ExampleDTO dto);

}
